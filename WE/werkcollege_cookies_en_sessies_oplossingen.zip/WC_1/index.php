<?php include "taalkeuze.php"; ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title><?php echo $indextitel; ?> </title>
    </head>
    <body>
        <h1><?php echo $indextitel; ?></h1>
        <div>
            <?php echo $indextekst; ?>
        </div>
        <a href="instellingen.php"><?php echo $indexlink; ?></a>
    </body>
</html>
