<?php
$indextitel = "Welkom";
$indextekst = "Welkom op deze webpagina ";
$indexlink = "Instellingen";
$instellingentitel = "Instellingen";
$instellingenuitleg = "Kies een taal en druk op de knop om op te slaan";
$instellingenopslaan = "Opslaan";
$instellingenterug = "Terug";
?>