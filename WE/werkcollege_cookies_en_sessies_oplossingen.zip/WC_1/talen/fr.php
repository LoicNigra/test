<?php
$indextitel = "Bienvenue";
$indextekst = "Bienvenue sur cette page ";
$indexlink = "Parametres";
$instellingentitel = "Parametres";
$instellingenuitleg = "Choisissez votre langue en appuyez le bouton pour enregistrer";
$instellingenopslaan = "Enregistrer";
$instellingenterug = "Home";
?>