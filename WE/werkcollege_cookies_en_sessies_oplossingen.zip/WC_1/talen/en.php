<?php
$indextitel = "Welcome";
$indextekst = "Welcome to this web page ";
$indexlink = "Settings";
$instellingentitel = "Settings";
$instellingenuitleg = "Choose a language and press the button to save the settings";
$instellingenopslaan = "Save settings";
$instellingenterug = "Back";
?>