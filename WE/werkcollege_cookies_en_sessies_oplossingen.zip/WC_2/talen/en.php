<?php
$indextitel = "Welcome";
$indextekst = "Welcome to this web page ";
$indexlink = "Settings";
$instellingentitel = "Settings";
$instellingenuitleg = "Press the button to save the settings";
$instellingentaal = "Choose a language";
$instellingenachtergrondkleur = "The background-color of your choice";
$instellingentijdszone = "Your timezone:";
$instellingennaam = "Your name:";
$instellingenopslaan = "Save settings";
$instellingenterug = "Back";
?>