<?php
$indextitel = "Welkom";
$indextekst = "Welkom op deze webpagina ";
$indexlink = "Instellingen";
$instellingentitel = "Instellingen";
$instellingenuitleg = "Druk op de knop om op te slaan";
$instellingentaal = "Kies een taal";
$instellingenachtergrondkleur = "De achtergrondkleur van uw keuze";
$instellingentijdszone = "Uw tijdszone:";
$instellingennaam = "Uw naam:";
$instellingenopslaan = "Opslaan";
$instellingenterug = "Terug";
?>