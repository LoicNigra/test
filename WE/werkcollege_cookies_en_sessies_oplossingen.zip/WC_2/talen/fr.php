<?php
$indextitel = "Bienvenue";
$indextekst = "Bienvenue sur cette page ";
$indexlink = "Parametres";
$instellingentitel = "Parametres";
$instellingenuitleg = "Appuyez le bouton pour enregistrer";
$instellingentaal = "Choisissez votre langue";
$instellingenachtergrondkleur = "Couleur pour le fond";
$instellingentijdszone = "Votre fuseau horaire:";
$instellingennaam = "Votre nom:";
$instellingenopslaan = "Enregistrer";
$instellingenterug = "Home";
?>