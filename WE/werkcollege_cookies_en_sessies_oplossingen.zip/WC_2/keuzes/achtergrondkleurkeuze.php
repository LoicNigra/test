<?php
  $achtergrondkleur="#FFFFFF";
  if (isset($_COOKIE["achtergrondkleur"])){
     $achtergrondkleur = $_COOKIE["achtergrondkleur"];
  }
?>

