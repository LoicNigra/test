<?php
  $naam="bezoeker";
  if (isset($_COOKIE["naam"])){
     $naam = $_COOKIE["naam"];
  }
?>
