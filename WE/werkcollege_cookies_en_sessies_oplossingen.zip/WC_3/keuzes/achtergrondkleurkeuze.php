<?php
  $achtergrondkleur="#FFFFFF";
  if (isset($_SESSION["achtergrondkleur"])){
    $achtergrondkleur = $_SESSION["achtergrondkleur"];
  }
?>

