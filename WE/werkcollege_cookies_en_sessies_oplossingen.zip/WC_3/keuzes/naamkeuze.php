<?php
  $naam="bezoeker";
  if (isset($_SESSION["naam"])){
    $naam = $_SESSION["naam"];
  }
?>
