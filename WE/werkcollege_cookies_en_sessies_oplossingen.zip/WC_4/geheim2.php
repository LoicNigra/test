<?php include_once 'security.php'; ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>Geheim 2</h1>
        <a href="geheim1.php">Geheim1</a>
        <br>
        <a href="logout.php">Logout</a>
    </body>
</html>
