<?php header("location:http://www.google.be"); ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        U wordt nu doorgestuurd naar www.google.be...
    </body>
</html>
